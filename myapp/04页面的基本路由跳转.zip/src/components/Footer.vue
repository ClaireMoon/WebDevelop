<template>
  <footer class="footer">
    <ul>
      <li>
        <span class="iconfont icon-shouye"></span>
        <p>首页</p>
      </li>
      <li>
        <span class="iconfont icon-icon"></span>
        <p>分类</p>
      </li>
      <li>
        <span class="iconfont icon-tuanduicankaoxian-"></span>
        <p>购物车</p>
      </li>
      <li>
        <span class="iconfont icon-wode"></span>
        <p>我的</p>
      </li>
    </ul>
  </footer>
</template>
